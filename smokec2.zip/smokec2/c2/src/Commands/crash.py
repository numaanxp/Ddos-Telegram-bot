from src.Commands.local_attack import attack_handler
def crash(args, validate_time, send, client, ansi_clear, broadcast, data):
    attack_handler(args, send, client, broadcast, data, "crash")
