from src.Commands.local_attack import attack_handler
def browser(args, validate_time, send, client, ansi_clear, broadcast, data):
    attack_handler(args, send, client, broadcast, data, "browser")
